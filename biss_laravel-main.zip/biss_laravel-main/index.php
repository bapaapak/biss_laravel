<?php

/**
 * Redirect to Laravel's public folder.
 * Digunakan khusus untuk Shared Hosting (cPanel) dimana Document Root 
 * tidak diarahkan secara default ke folder /public.
 */
require __DIR__ . '/public/index.php';
